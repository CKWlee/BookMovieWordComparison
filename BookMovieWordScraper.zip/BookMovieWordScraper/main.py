import os
import re
import requests
import matplotlib.pyplot as plt

# === MOVIES ===
# Dictionary mapping movie genres to movie titles and their corresponding script URLs
movies_by_genre = {
    "Comedy": {
        "Superbad": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=superbad",
        "Step Brothers": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=step-brothers",
        "The Hangover": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=hangover-the",
        "Anchorman": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=anchorman-the-legend-of-ron-burgundy",
        "Bridesmaids": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=bridesmaids"
    },
    "Sci-Fi": {
        "Inception": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=inception",
        "Interstellar": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=interstellar",
        "The Matrix": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=matrix-the",
        "Blade Runner": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=blade-runner",
        "Arrival": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=arrival"
    },
    "Drama": {
        "Forrest Gump": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=forrest-gump",
        "Shawshank Redemption": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=shawshank-redemption-the",
        "The Godfather": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=godfather-the",
        "A Beautiful Mind": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=beautiful-mind-a",
        "The Pursuit of Happyness": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=pursuit-of-happyness-the"
    },
    "Action": {
        "Die Hard": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=die-hard",
        "Mad Max: Fury Road": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=mad-max-fury-road",
        "John Wick": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=john-wick",
        "Gladiator": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=gladiator",
        "The Dark Knight": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=dark-knight-the-batman-the-dark-knight"
    },
    "Horror": {
        "Get Out": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=get-out",
        "The Shining": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=shining-the",
        "Hereditary": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=hereditary",
        "The Conjuring": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=the-conjuring",
        "Scream": "https://www.springfieldspringfield.co.uk/movie_script.php?movie=scream"
    }
}

# === Function to scrape and extract plain text from a movie script webpage ===
def get_script_text(url):
    try:
        res = requests.get(url)  # Send HTTP request to the script URL
        res.raise_for_status()   # Raise error if the request failed (non-200 status)
        # Extract the script content inside the HTML container using regex
        match = re.search(r'<div class="scrolling-script-container">(.+?)</div>', res.text, re.DOTALL)
        if match:
            # Strip HTML tags to get clean script text
            return re.sub('<[^<]+?>', '', match.group(1))
    except Exception as e:
        print(f"Failed to fetch {url}: {e}")
    return ""

# === Function to count the number of words in a given text ===
def word_count(text):
    return len(re.findall(r'\b\w+\b', text))  # Counts all word-like sequences using regex

# === Process all movie scripts and compute word counts per genre ===
movie_genre_word_counts = {}
for genre, movies in movies_by_genre.items():
    movie_genre_word_counts[genre] = {}
    for title, url in movies.items():
        print(f"Processing movie: {title}")
        script = get_script_text(url)
        movie_genre_word_counts[genre][title] = word_count(script)

# === Calculate average word count per movie genre ===
movie_avg_counts = {
    genre: sum(data.values()) / len(data)
    for genre, data in movie_genre_word_counts.items()
}

# === BOOKS ===
# Dictionary mapping book genres to local .txt file paths for each title
books_by_genre = {
    "Horror": {
        "Dracula": "books/dracula.txt",
        "Frankenstein": "books/frankenstein.txt",
        "The Phantom of the Opera": "books/phantom_opera.txt",
        "The Beetle": "books/beetle.txt",
        "The Trial": "books/trial.txt"
    },
    "Romance": {
        "Pride and Prejudice": "books/pride_and_prejudice.txt",
        "Jane Eyre": "books/jane_eyre.txt",
        "Emma": "books/emma.txt",
        "Sense and Sensibility": "books/sense_and_sensibility.txt",
        "Persuasion": "books/persuasion.txt"
    },
    "Science Fiction": {
        "War of the Worlds": "books/war_of_the_worlds.txt",
        "The Invisible Man": "books/invisible_man.txt",
        "We": "books/we.txt",
        "Journey to Center": "books/journey_to_center.txt",
        "Twenty Thousand Leagues": "books/twenty_thousand_leagues.txt"
    },
    "Mystery": {
        "The Hound of the Baskervilles": "books/hound_baskervilles.txt",
        "The Mystery of the Yellow Room": "books/yellow_room.txt",
        "The Mysterious Affair at Styles": "books/styles.txt",
        "The Woman in White": "books/woman_white.txt",
        "Daredevil": "books/daredevil.txt"
    },
    "Adventure": {
        "Moby Dick": "books/moby_dick.txt",
        "Treasure Island": "books/treasure_island.txt",
        "Tom Sawyer": "books/tom_sawyer.txt",
        "Huckleberry Finn": "books/huckleberry_finn.txt",
        "Robinson Crusoe": "books/robinson_crusoe.txt"
    }
}

# === Function to read and return the full text of a local book file ===
def get_local_book_text(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return ""

# === Process all books and compute word counts per genre ===
book_genre_word_counts = {}
for genre, books in books_by_genre.items():
    book_genre_word_counts[genre] = {}
    for title, path in books.items():
        print(f"Processing book: {title}")
        text = get_local_book_text(path)
        count = word_count(text)
        book_genre_word_counts[genre][title] = count

# === Compute average word counts for books per genre, ignoring unreadable files ===
book_avg_counts = {}
for genre, books in book_genre_word_counts.items():
    valid_counts = [count for count in books.values() if count > 0]
    if valid_counts:
        book_avg_counts[genre] = sum(valid_counts) / len(valid_counts)
    else:
        book_avg_counts[genre] = 0

# === PLOTTING RESULTS ===

# === Create bar chart: average word count by movie genre ===
plt.figure(figsize=(12, 6))
bars = plt.bar(movie_avg_counts.keys(), movie_avg_counts.values(), color='skyblue')
for bar in bars:
    height = bar.get_height()
    # Annotate each bar with its word count
    plt.text(bar.get_x() + bar.get_width() / 2, height, f"{int(height)}", ha='center', va='bottom')
plt.title("Average Word Count by Movie Genre")
plt.xlabel("Movie Genre")
plt.ylabel("Average Word Count")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("movie_genre_word_counts.png")  # Save movie chart to file

# === Create bar chart: average word count by book genre ===
plt.figure(figsize=(12, 6))
bars = plt.bar(book_avg_counts.keys(), book_avg_counts.values(), color='lightgreen')
for bar in bars:
    height = bar.get_height()
    # Annotate each bar with its word count
    plt.text(bar.get_x() + bar.get_width() / 2, height, f"{int(height)}", ha='center', va='bottom')
plt.title("Average Word Count by Book Genre")
plt.xlabel("Book Genre")
plt.ylabel("Average Word Count")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("book_genre_word_counts.png")  # Save book chart to file

# === Final confirmation message ===
print("✅ Saved plots: movie_genre_word_counts.png and book_genre_word_counts.png")
